<?php return array (
  'counter' => 'App\\Http\\Livewire\\Counter',
  'product.create' => 'App\\Http\\Livewire\\Product\\Create',
  'product.index' => 'App\\Http\\Livewire\\Product\\Index',
  'product.update' => 'App\\Http\\Livewire\\Product\\Update',
  'shop.cart' => 'App\\Http\\Livewire\\Shop\\Cart',
  'shop.cartnav' => 'App\\Http\\Livewire\\Shop\\Cartnav',
  'shop.checkout' => 'App\\Http\\Livewire\\Shop\\Checkout',
  'shop.index' => 'App\\Http\\Livewire\\Shop\\Index',
);