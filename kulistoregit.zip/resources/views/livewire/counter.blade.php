<div class="mt-3 mb-5 text-center">
    <h1 class="font-weight-bold">Welcome to KuliStore</h1> 
    <h2 style="color: rgb(72, 197, 72)"> <a href="/shop" class="btn-lg btn-success">Klik disini untuk mulai belanja!</a></h2>
</div>




<div class="row p-3 no-gutter">

<div class="col-4 text-center wow fadeIn" data-wow-delay="0.3s">
    <img src="img/konten1.png" alt="" style="height: 500px;">
</div>
<div class="col-4 text-center wow fadeIn" data-wow-delay="0.6s">
    <img src="img/konten2.png" alt="" style="height: 500px;">
</div>
<div class="col-4 text-center wow fadeIn" data-wow-delay="0.9s">
    <img src="img/konten3.png" alt="" style="height: 500px;">
</div>


</div>

