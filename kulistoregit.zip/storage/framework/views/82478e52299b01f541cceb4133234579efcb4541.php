    <div class="container">

        <?php if($formVisible): ?>
            <?php if(! $formUpdate): ?>
                <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('product.create')->dom;
} elseif ($_instance->childHasBeenRendered('n15RNUq')) {
    $componentId = $_instance->getRenderedChildComponentId('n15RNUq');
    $componentTag = $_instance->getRenderedChildComponentTagName('n15RNUq');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('n15RNUq');
} else {
    $response = \Livewire\Livewire::mount('product.create');
    $dom = $response->dom;
    $_instance->logRenderedChild('n15RNUq', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
            <?php else: ?>
                <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('product.update')->dom;
} elseif ($_instance->childHasBeenRendered('YXqJzkC')) {
    $componentId = $_instance->getRenderedChildComponentId('YXqJzkC');
    $componentTag = $_instance->getRenderedChildComponentTagName('YXqJzkC');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YXqJzkC');
} else {
    $response = \Livewire\Livewire::mount('product.update');
    $dom = $response->dom;
    $_instance->logRenderedChild('YXqJzkC', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>              
            <?php endif; ?>
        <?php endif; ?>

        <div class="row justify-content-center mt-5">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <button wire:click="$toggle('formVisible')" class="btn btn-sm btn-primary"><i class="fas fa-plus mr-2"></i>Tambah Barang</button>
                    </div>

                    <div class="card-body">

                        <?php if(session()->has('message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('message')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="row">
                            <div class="col">
                                <select wire:model="paginate" name="" id="" class="form-control form-control-sm w-auto">
                                    <option value="5">5</option>
                                    <option value="10">10</option>
                                    <option value="15">15</option>
                                    <option value="20">20</option>
                                </select>
                            </div>
                            <div class="col">
                                <input wire:model="search" type="text" class="form-control form-control-sm" placeholder="Search">
                            </div>
                        </div>

                        <hr>

                        <table class="table">
                            <thead class="thead-dark">
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Title</th>
                                    <th scope="col">Price</th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 0 ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $no++ ?>
                                <tr>
                                    <th scope="row"><?php echo e($no); ?></th>
                                    <td><?php echo e($product->title); ?></td>
                                    <td>Rp<?php echo e(number_format($product->price,2,",",".")); ?></td>
                                    <td>
                                        <button wire:click="editProduct(<?php echo e($product->id); ?>)" class="btn btn-sm btn-info text-white">Edit</button>
                                        <button wire:click="deleteProduct(<?php echo e($product->id); ?>)" class="btn btn-sm btn-danger" onclick="return confirm('Yakin Hapus data?')">Delete</button>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <?php echo e($products->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php /**PATH C:\laragon\www\kulistoregit\resources\views/livewire/product/index.blade.php ENDPATH**/ ?>