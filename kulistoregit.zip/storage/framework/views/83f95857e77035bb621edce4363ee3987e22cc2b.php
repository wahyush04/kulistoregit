

<?php $__env->startSection('content'); ?>
<div class="p-3 mt-4">
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="img/howl.png" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="img/ddd.png" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="img/cd.png" class="d-block w-100" alt="...">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</div>
<?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('counter')->dom;
} elseif ($_instance->childHasBeenRendered('FKqUa3w')) {
    $componentId = $_instance->getRenderedChildComponentId('FKqUa3w');
    $componentTag = $_instance->getRenderedChildComponentTagName('FKqUa3w');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FKqUa3w');
} else {
    $response = \Livewire\Livewire::mount('counter');
    $dom = $response->dom;
    $_instance->logRenderedChild('FKqUa3w', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kulistoregit\resources\views/home.blade.php ENDPATH**/ ?>