

<?php $__env->startSection('content'); ?>
    <style type="text/css">
        body {
            background: #FFFFFF;
        }

        @import  url('https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500&display=swap');

    </style>

    <div class="container" style="margin-top: 30px">
        <div class="card shadow">
            <div class="card-body">
                <h5>
                    <p class="font-weight-bold ml-2">Edit Data diri</p>
                </h5>
                <hr>
                <div class="row align-items-top mb-3">
                    <div class="col-3">
                        <img src="/img/<?php echo e(Auth::user()->image); ?>" class="img-thumbnail">

                        </form>

                    </div>
                    <div class="col-9">
                        <form method="POST" action="/profile/<?php echo e($user->id); ?>">
                            <?php echo method_field('patch'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="nama_lengkap" class="font-weight-bold">Nama Lengkap</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="nama_lengkap" placeholder="Masukkan Nama Lengkap Anda" name="nama_lengkap"
                                    value="<?php echo e(Auth::user()->full_name); ?>">
                                <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div id="validationServer03Feedback" class="invalid-feedback">
                                    <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="alamat" class="font-weight-bold">Alamat</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alamat"
                                    placeholder="Masukkan Alamat" name="alamat" value="<?php echo e(Auth::user()->address); ?>">
                                <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div id="validationServer03Feedback" class="invalid-feedback">
                                    <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="tgl_lahir" class="font-weight-bold">Tanggal Lahir</label>
                                <input type="date" class="form-control <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="tgl_lahir" placeholder="Masukkan Tanggal Lahir" name="tgl_lahir"
                                    value="<?php echo e(Auth::user()->born_date); ?>">
                                <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div id="validationServer03Feedback" class="invalid-feedback">
                                    <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="jenis_kelamin" class="font-weight-bold">Jenis Kelamin</label> <br>
                                <select name='jenis_kelamin'>
                                    <option value='Pria'>Pria</option>
                                    <option value='Wanita'>Wanita</option>
                                </select>
                            </div>

                            <label for="tgl_lahir" class="font-weight-bold">Pilih Gambar</label> <br>
                            <input type="file" id="image" name="image"> 
                            
                            <hr>
                            <h5 class="mt-4">
                                <p class="font-weight-bold ml-2">Kontak</p>
                            </h5>
                            <hr>

                            <div class="mb-3">
                                <label for="email" class="font-weight-bold mt-3">Email</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email"
                                    placeholder="Masukkan Email" name="email" value="<?php echo e(Auth::user()->email); ?>">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div id="validationServer03Feedback" class="invalid-feedback">
                                    <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="nomor_hp" class="font-weight-bold">Nomor Hp</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['nomor_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="nomor_hp" placeholder="Masukkan Nomor Hp" name="nomor_hp"
                                    value="<?php echo e(Auth::user()->phone_number); ?>">
                                <?php $__errorArgs = ['nomor_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div id="validationServer03Feedback" class="invalid-feedback">
                                    <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <button type="submit" class="btn btn-primary float-right">Simpan</button>
                    </div>

                </div>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="./assets/js/bootstrap.bundle.min.js"></script>
        <script src="https://kit.fontawesome.com/a7fbc8a9d9.js" crossorigin="anonymous"></script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kulistoregit\resources\views/profile/edit.blade.php ENDPATH**/ ?>