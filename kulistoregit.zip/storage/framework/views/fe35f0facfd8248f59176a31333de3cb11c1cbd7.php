<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <table class="table">
                        <thead class="thead-dark">
                            <tr>    
                                <th>No</th>
                                <th>Gambar</th>
                                <th>Nama</th>
                                <th>Harga</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $cart['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><img class="rounded" style="height:30px; width:25px;"
                                    src="<?php echo e($product->image ? asset('/storage/' . $product->image) : 'http://placehold.it/150x150'); ?>"
                                    alt=""></td>
                                    <td><?php echo e($product->title); ?></td>
                                    <td>Rp<?php echo e(number_format($product->price, 2, ',', '.')); ?></td>
                                    <td>
                                        <button wire:click="removeFromCart(<?php echo e($product->id); ?>)"
                                            class="btn btn-sm btn-danger">
                                            Hapus
                                        </button>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>         
                    </table>
                    <div class="text-center mt-5">

                        <?php if($cart['products']): ?>
                        <a href="<?php echo e(route('shop.checkout')); ?>" class="btn-lg btn-primary">
                            Checkout
                        </a>
                        <?php else: ?>
                        <h3>Wah, keranjang belanjamu kosong!</h3>
                        <p>Yuk, isi dengan barang-barang impianmu</p>
                        <a href="<?php echo e(route('shop.index')); ?>" class="btn-lg btn-success font-weight-bold m-3">
                            Mulai belanja
                        </a>
                        <?php endif; ?>
                    
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\kulistoregit\resources\views/livewire/shop/cart.blade.php ENDPATH**/ ?>