
    <li class="nav-item">
        <a href="<?php echo e(route('shop.cart')); ?>" class="nav-link "">
            <i class="fas fa-shopping-cart"></i>

            <?php if($cartTotal != 0): ?>
            <span class="badge badge-danger"><?php echo e($cartTotal); ?></span>
            <?php endif; ?>
        </a>


    </li>

<?php /**PATH C:\laragon\www\kulistoregit\resources\views/livewire/shop/cartnav.blade.php ENDPATH**/ ?>