<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="form-group">
                <input wire:model="search" type="text" class="form-control" placeholder="Search Product">
            </div>
        </div>
    </div>

    <div class="row">

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-3 mb-3 no-gutters">
            <div class="card rounded">
                <img class="rounded-top" style="height:250px;"
                    src="<?php echo e($product->image ? asset('/storage/' . $product->image) : 'http://placehold.it/150x150'); ?>"
                    alt="">
                <div class="card-body">
                    <h5 class="text-black" style="margin-top: -10px">
                        <strong><?php echo e($product->title); ?></strong>
                    </h5>
                    <h6 class="text-black ">Rp<?php echo e(number_format($product->price, 2, ',', '.')); ?></h6>
                    <i class="fas fa-star" style="color: #FFC947"></i><i class="fas fa-star"  style="color: #FFC947"></i><i class="fas fa-star"  style="color: #FFC947"></i><i class="fas fa-star-half-alt"  style="color: #FFC947"></i><i class="far fa-star"  style="color: #FFC947"></i>
                    <button wire:click="addToCart(<?php echo e($product->id); ?>)" type="button"
                        class="btn btn-sm btn-block btn-primary text-white mb-2 ">+ Keranjang</button>
                    <button type="button" class="btn btn-sm btn-block btn-secondary text-white mb-2"
                        data-bs-toggle="modal" data-bs-target="#modal<?php echo e($product->id); ?>">Detail Barang</button>
                </div>
            </div>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="modal<?php echo e($product->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title font-weight-bold" id="exampleModalLabel"><?php echo e($product->title); ?></h5>
                    </div>


                    <div class="modal-body">
                        <div class="row">
                            <div class="col-5">
                                <img class="rounded" style="height:300px; width:275px;"
                                    src="<?php echo e($product->image ? asset('/storage/' . $product->image) : 'http://placehold.it/150x150'); ?>"
                                    alt="">
                            </div>
                            <div class="col-7">
                                <h5>Deskripsi Barang:</h5>
                                <p class="text-black">
                                    <?php echo e($product->description); ?>

                                </p>
                                <h4 class="text-black mr-5">Rp<?php echo e(number_format($product->price, 2, ',', '.')); ?></h4>
                            </div>
                        </div>
                    </div>


                    <div class="modal-footer float-left">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <a wire:click="addToCart(<?php echo e($product->id); ?>)" class="btn btn-primary" href="<?php echo e(Route('shop.index')); ?>">+ Keranjang</a>

                    </div>
                </div>
            </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <?php echo e($products->links()); ?>

</div>
<?php /**PATH C:\laragon\www\kulistoregit\resources\views/livewire/shop/index.blade.php ENDPATH**/ ?>